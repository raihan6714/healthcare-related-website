const firebaseConfig = {
    apiKey: "AIzaSyAqf_ijAmPhj2AMu3JWx26Y8X_Y62DohNw",
    authDomain: "optima-mental-hospital.firebaseapp.com",
    projectId: "optima-mental-hospital",
    storageBucket: "optima-mental-hospital.appspot.com",
    messagingSenderId: "136541971585",
    appId: "1:136541971585:web:df9083c39e25e58fc65980"
};
export default firebaseConfig;