import React from 'react';
import Navbar from '../../Shared/Navbar/Navbar';

const Header = () => {
    return (
        <>
            <Navbar></Navbar>
        </>
    );
};

export default Header;